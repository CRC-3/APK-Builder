package com.orion.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import java.math.BigDecimal
import java.math.MathContext
import java.math.RoundingMode

class MainActivity : AppCompatActivity() {

    private lateinit var display: TextView

    private var input = StringBuilder()
    private var accumulator = BigDecimal.ZERO
    private var pendingOp: Char? = null
    private val mc = MathContext(16, RoundingMode.HALF_UP)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        display = findViewById(R.id.display)

        val digitButtons = listOf(
            R.id.btn0 to "0", R.id.btn1 to "1", R.id.btn2 to "2",
            R.id.btn3 to "3", R.id.btn4 to "4", R.id.btn5 to "5",
            R.id.btn6 to "6", R.id.btn7 to "7", R.id.btn8 to "8", R.id.btn9 to "9"
        )
        digitButtons.forEach { (id, digit) ->
            findViewById<Button>(id).setOnClickListener { appendDigit(digit) }
        }

        findViewById<Button>(R.id.btnDot).setOnClickListener { appendDot() }
        findViewById<Button>(R.id.btnClear).setOnClickListener { clearAll() }

        findViewById<Button>(R.id.btnPlus).setOnClickListener { operator('+') }
        findViewById<Button>(R.id.btnMinus).setOnClickListener { operator('-') }
        findViewById<Button>(R.id.btnMultiply).setOnClickListener { operator('×') }
        findViewById<Button>(R.id.btnDivide).setOnClickListener { operator('÷') }

        findViewById<Button>(R.id.btnEquals).setOnClickListener { equals() }

        updateDisplay("0")
    }

    private fun appendDigit(d: String) {
        if (input.length == 1 && input[0] == '0') input.clear()
        input.append(d)
        updateDisplay(input.toString())
    }

    private fun appendDot() {
        if (!input.contains('.')) {
            if (input.isEmpty()) input.append('0')
            input.append('.')
            updateDisplay(input.toString())
        }
    }

    private fun clearAll() {
        input.clear()
        accumulator = BigDecimal.ZERO
        pendingOp = null
        updateDisplay("0")
    }

    private fun parseInput(): BigDecimal {
        return if (input.isEmpty()) BigDecimal.ZERO else input.toString().toBigDecimal(mc)
    }

    private fun applyPending(right: BigDecimal) {
        accumulator = when (pendingOp) {
            '+' -> accumulator.add(right, mc)
            '-' -> accumulator.subtract(right, mc)
            '×' -> accumulator.multiply(right, mc)
            '÷' -> if (right.compareTo(BigDecimal.ZERO) == 0) BigDecimal.ZERO else accumulator.divide(right, mc)
            else -> right
        }
    }

    private fun operator(op: Char) {
        val value = parseInput()
        if (pendingOp == null) {
            accumulator = value
        } else {
            applyPending(value)
        }
        pendingOp = op
        input.clear()
        updateDisplay(trimZeros(accumulator))
    }

    private fun equals() {
        val value = parseInput()
        applyPending(value)
        pendingOp = null
        input.clear()
        input.append(trimZeros(accumulator))
        updateDisplay(input.toString())
    }

    private fun trimZeros(num: BigDecimal): String {
        val s = num.stripTrailingZeros().toPlainString()
        return if (s == "-0") "0" else s
    }

    private fun updateDisplay(text: String) {
        display.text = text
    }
}
