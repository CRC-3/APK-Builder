
rootProject.name = "FreshCalc"
include(":app")
