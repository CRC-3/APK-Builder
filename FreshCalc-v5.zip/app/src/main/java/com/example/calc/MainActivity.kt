
package com.example.calc

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { CalculatorApp() }
    }
}

@Composable
fun CalculatorApp() {
    var input by remember { mutableStateOf("") }
    var result by remember { mutableStateOf("0") }

    Column(modifier = Modifier.padding(16.dp)) {
        Text(text = "Result: $result", style = MaterialTheme.typography.headlineMedium)
        OutlinedTextField(
            value = input,
            onValueChange = { input = it },
            label = { Text("Enter expression (e.g. 2+2)") },
            modifier = Modifier.fillMaxWidth()
        )
        Button(
            onClick = {
                try {
                    result = eval(input).toString()
                } catch (e: Exception) {
                    result = "Error"
                }
            },
            modifier = Modifier.padding(top = 8.dp)
        ) {
            Text("Calculate")
        }
    }
}

fun eval(expr: String): Double {
    return javax.script.ScriptEngineManager().getEngineByName("rhino").eval(expr).toString().toDouble()
}
